export enum UploadStatus {
    NotStarted = 0,
    Uploading = 1,
    Done = 2,
    Error = 3
}